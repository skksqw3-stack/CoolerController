Cooler Control - Kotlin port of the Kivy app
============================================

Screens (same as the Kivy version): Home, Timer, Status, Settings.
Protocol: 1 2 3 4 T t s hFA hEN, S+HHMM, ON+HHMM, OFF+HHMM  (each command ends with LF).

Works on Android 4.4 (API 19) and newer (minSdk 19, targetSdk 28, Bluetooth Classic SPP / HC-05).
Build: GitHub Actions (.github/workflows/build.yml) or  gradle assembleDebug  (JDK 17, Gradle 8.7).

Launcher icon: generated from the supplied icon.png (mipmap-*/ic_launcher.png);
the same artwork is used in the Home header (drawable-nodpi/app_logo.png).

Notes
- Pair the HC-05 in Android Bluetooth settings first, then Settings > Load Devices > Connect.
- If an older build is installed, uninstall it first.
- The app understands both the status lines (Temp:, Humidity:, Time:, Mode:, Pump:, Motor:, Timer:)
  and the periodic line  T:28.5,H:40.0,TM:1  sent by the updated firmware.
  Periodic lines update the screens but are not written to the log.
