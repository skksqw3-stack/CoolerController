package com.example.cooler

import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.Spinner
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.example.cooler.databinding.ActivityMainBinding
import com.google.android.material.button.MaterialButton
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.io.OutputStream
import java.util.Locale
import java.util.UUID
import java.util.concurrent.Executors

/**
 * Cooler Control - Kotlin port of the Kivy app (main.py + cooler.kv +
 * bluetooth_manager.py + time_picker.py + numeric_keypad.py).
 *
 * Works on Android 4.4 (API 19) and newer.
 * Protocol (every command ends with LF):
 *   fixed:   1, 2, 3, 4, T, t, s, hFA, hEN
 *   dynamic: S+HHMM, ON+HHMM, OFF+HHMM
 */
class MainActivity : AppCompatActivity() {

    private enum class Screen { HOME, TIMER, STATUS, SETTINGS }

    private lateinit var b: ActivityMainBinding

    private val ui = Handler(Looper.getMainLooper())
    private val writer = Executors.newSingleThreadExecutor()   // only for writing to the socket
    private val writeLock = Any()

    private val sppUuid: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    private var btAdapter: BluetoothAdapter? = null

    @Volatile private var socket: BluetoothSocket? = null
    @Volatile private var outStream: OutputStream? = null
    @Volatile private var connected = false
    @Volatile private var connecting = false
    @Volatile private var closing = false
    private var connectedName = ""
    private var pairedDevices: List<BluetoothDevice> = emptyList()

    private var current = Screen.HOME
    private var isPersian = false

    // values shown on Home / Status
    private var temperature = "--.-"
    private var humidity = "--.-"
    private var rtcTime = "--:--"

    private var pumpState = "Unknown"
    private var motorState = "Unknown"
    private var modeState = "Unknown"
    private var timerState = "Unknown"

    private val logLines = ArrayList<String>()
    private var clockDigits = ""

    // periodic line sent by the Arduino firmware: T:28.5,H:40.0,TM:1
    private val sensorRegex = Regex("""T:(-?\d+(?:\.\d+)?),H:(\d+(?:\.\d+)?)(?:,TM:([01]))?""")

    // ✅ وضعیت برای ارسال خودکار دستور s
    private var isAutoRefreshRunning = false

    // =====================================================
    // Lifecycle
    // =====================================================

    override fun onCreate(savedInstanceState: Bundle?) {
        val prefs = getSharedPreferences("cooler_prefs", Context.MODE_PRIVATE)
        isPersian = prefs.getBoolean("is_persian", false)
        val isDark = prefs.getBoolean("is_dark", true)
        AppCompatDelegate.setDefaultNightMode(
            if (isDark) AppCompatDelegate.MODE_NIGHT_YES else AppCompatDelegate.MODE_NIGHT_NO
        )

        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        btAdapter = BluetoothAdapter.getDefaultAdapter()

        setupHome()
        setupTimer()
        setupStatus()
        setupSettings()

        applyLanguageTexts()
        showScreen(Screen.HOME)
        updateHome()
        updateConnectionUi()
        addLog("App is ready.")
        refreshDevices()
    }

    override fun onDestroy() {
        closing = true
        stopAutoRefresh() // ✅ توقف تایمر هنگام بستن اپ
        closeQuietly()
        writer.shutdownNow()
        ui.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (current != Screen.HOME) showScreen(Screen.HOME) else super.onBackPressed()
    }

    // =====================================================
    // Top-right Hamburger Menu (Language, Day/Night, Settings)
    // =====================================================

    private fun showTopMenu(anchor: View) {
        val popup = PopupMenu(this, anchor)
        val langLabel = if (isPersian) "زبان: فارسی / English" else "Language: English / فارسی"
        val themeLabel = if (isNightModeActive()) {
            if (isPersian) "حالت روز ☀️" else "Day Mode ☀️"
        } else {
            if (isPersian) "حالت شب 🌙" else "Night Mode 🌙"
        }
        val settingsLabel = if (isPersian) "تنظیمات ⚙️" else "Settings ⚙️"

        popup.menu.add(0, 1, 0, langLabel)
        popup.menu.add(0, 2, 1, themeLabel)
        popup.menu.add(0, 3, 2, settingsLabel)

        popup.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                1 -> {
                    toggleLanguage()
                    true
                }
                2 -> {
                    toggleDayNightMode()
                    true
                }
                3 -> {
                    openSettings()
                    true
                }
                else -> false
            }
        }
        popup.show()
    }

    private fun isNightModeActive(): Boolean {
        val mode = AppCompatDelegate.getDefaultNightMode()
        if (mode == AppCompatDelegate.MODE_NIGHT_YES) return true
        if (mode == AppCompatDelegate.MODE_NIGHT_NO) return false
        val nightMask = resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK
        return nightMask == Configuration.UI_MODE_NIGHT_YES
    }

    private fun toggleDayNightMode() {
        val nextDark = !isNightModeActive()
        getSharedPreferences("cooler_prefs", Context.MODE_PRIVATE)
            .edit()
            .putBoolean("is_dark", nextDark)
            .apply()
        AppCompatDelegate.setDefaultNightMode(
            if (nextDark) AppCompatDelegate.MODE_NIGHT_YES else AppCompatDelegate.MODE_NIGHT_NO
        )
    }

    private fun toggleLanguage() {
        isPersian = !isPersian
        getSharedPreferences("cooler_prefs", Context.MODE_PRIVATE)
            .edit()
            .putBoolean("is_persian", isPersian)
            .apply()
        applyLanguageTexts()
        // Send protocol language command if connected (hFA / hEN)
        if (connected) {
            sendCommand(if (isPersian) "hFA" else "hEN")
        }
    }

    private fun translateValue(v: String): String {
        if (!isPersian) return v
        return when (v) {
            "ON" -> "روشن"
            "OFF" -> "خاموش"
            "Slow" -> "کند"
            "Fast" -> "تند"
            "Auto" -> "اتوماتیک"
            "Manual" -> "دستی"
            "Unknown" -> "نامشخص"
            else -> v
        }
    }

    private fun applyLanguageTexts() {
        if (isPersian) {
            // Home
            b.pageHome.tvAppTitle.text = "کنترل کولر"
            b.pageHome.btnPump.text = "💧 پمپ آب"
            b.pageHome.btnSlow.text = "دور کند"
            b.pageHome.btnFast.text = "دور تند"
            b.pageHome.btnMode.text = "حالت اتوماتیک/دستی"
            b.pageHome.navHome.text = "خانه"
            b.pageHome.navTimer.text = "تایمر"
            b.pageHome.navStatus.text = "وضعیت"
            b.pageHome.navSettings.text = "تنظیمات"

            // Timer
            b.pageTimer.tvTimerTitle.text = "تنظیم تایمر"
            b.pageTimer.tvOnTimeLabel.text = "زمان روشن شدن (ON)"
            b.pageTimer.tvOffTimeLabel.text = "زمان خاموش شدن (OFF)"
            b.pageTimer.btnSaveTimer.text = "ذخیره و ارسال"
            b.pageTimer.tvTimerFeedback.text = "زمان روشن و خاموش را انتخاب کنید"
            b.pageTimer.btnToggleTimer.text = "تغییر وضعیت تایمر"
            b.pageTimer.navTimerBack.text = "بازگشت به خانه"

            // Status
            b.pageStatus.tvStatusTitle.text = "وضعیت کولر"
            b.pageStatus.tvStTempLabel.text = "دما"
            b.pageStatus.tvStHumLabel.text = "رطوبت"
            b.pageStatus.tvStTimeLabel.text = "ساعت RTC"
            b.pageStatus.btnRefresh.text = "به‌روزرسانی"
            b.pageStatus.tvLogLabel.text = "گزارش ارتباط"
            b.pageStatus.navStatusHome.text = "خانه"
            b.pageStatus.navStatusSettings.text = "تنظیمات"

            // Settings
            b.pageSettings.tvSettingsTitle.text = "تنظیمات"
            b.pageSettings.tvBtSectionLabel.text = "اتصال بلوتوث کلاسیک / HC-05"
            b.pageSettings.btnLoadDevices.text = "لیست دستگاه‌ها"
            b.pageSettings.btnConnect.text = "اتصال"
            b.pageSettings.btnDisconnect.text = "قطع اتصال"
            b.pageSettings.tvRtcSectionLabel.text = "تنظیم ساعت RTC (HHMM)"
            b.pageSettings.btnSendClock.text = "ارسال تنظیم ساعت"
            b.pageSettings.tvClockFeedback.text = "۴ رقم ساعت را وارد کنید"
            b.pageSettings.navSettingsBack.text = "بازگشت به خانه"
        } else {
            // Home
            b.pageHome.tvAppTitle.text = "Cooler Control"
            b.pageHome.btnPump.text = "💧 Pump"
            b.pageHome.btnSlow.text = "Slow Motor"
            b.pageHome.btnFast.text = "Fast Motor"
            b.pageHome.btnMode.text = "Mode Auto/Manual"
            b.pageHome.navHome.text = "Home"
            b.pageHome.navTimer.text = "Timer"
            b.pageHome.navStatus.text = "Status"
            b.pageHome.navSettings.text = "Settings"

            // Timer
            b.pageTimer.tvTimerTitle.text = "Timer Setup"
            b.pageTimer.tvOnTimeLabel.text = "ON Time (Turn On)"
            b.pageTimer.tvOffTimeLabel.text = "OFF Time (Turn Off)"
            b.pageTimer.btnSaveTimer.text = "Save and Send"
            b.pageTimer.tvTimerFeedback.text = "Select ON and OFF times"
            b.pageTimer.btnToggleTimer.text = "Toggle Timer ON/OFF"
            b.pageTimer.navTimerBack.text = "Back to Home"

            // Status
            b.pageStatus.tvStatusTitle.text = "Cooler Status"
            b.pageStatus.tvStTempLabel.text = "Temperature"
            b.pageStatus.tvStHumLabel.text = "Humidity"
            b.pageStatus.tvStTimeLabel.text = "RTC Time"
            b.pageStatus.btnRefresh.text = "Refresh"
            b.pageStatus.tvLogLabel.text = "Communication Log"
            b.pageStatus.navStatusHome.text = "Home"
            b.pageStatus.navStatusSettings.text = "Settings"

            // Settings
            b.pageSettings.tvSettingsTitle.text = "Settings"
            b.pageSettings.tvBtSectionLabel.text = "Bluetooth Classic / HC-05 Connection"
            b.pageSettings.btnLoadDevices.text = "Load Devices"
            b.pageSettings.btnConnect.text = "Connect"
            b.pageSettings.btnDisconnect.text = "Disconnect"
            b.pageSettings.tvRtcSectionLabel.text = "Set RTC Clock (HHMM)"
            b.pageSettings.btnSendClock.text = "Send Clock Setting"
            b.pageSettings.tvClockFeedback.text = "Enter 4 digits for clock"
            b.pageSettings.navSettingsBack.text = "Back to Home"
        }

        updateHome()
        updateConnectionUi()
        updateTimerPreview()
        refreshStatusLabels()
    }

    private fun refreshStatusLabels() {
        if (isPersian) {
            b.pageStatus.tvStPump.text = "پمپ: ${translateValue(pumpState)}"
            b.pageStatus.tvStMotor.text = "موتور: ${translateValue(motorState)}"
            b.pageStatus.tvStMode.text = "حالت: ${translateValue(modeState)}"
            b.pageStatus.tvStTimer.text = "تایمر: ${translateValue(timerState)}"
            b.pageTimer.tvTimerState.text = "تایمر: ${translateValue(timerState)}"
        } else {
            b.pageStatus.tvStPump.text = "Pump: $pumpState"
            b.pageStatus.tvStMotor.text = "Motor: $motorState"
            b.pageStatus.tvStMode.text = "Mode: $modeState"
            b.pageStatus.tvStTimer.text = "Timer: $timerState"
            b.pageTimer.tvTimerState.text = "Timer: $timerState"
        }
    }

    // =====================================================
    // Screens / navigation
    // =====================================================

    private fun showScreen(s: Screen) {
        current = s
        b.pageHome.root.visibility = if (s == Screen.HOME) View.VISIBLE else View.GONE
        b.pageTimer.root.visibility = if (s == Screen.TIMER) View.VISIBLE else View.GONE
        b.pageStatus.root.visibility = if (s == Screen.STATUS) View.VISIBLE else View.GONE
        b.pageSettings.root.visibility = if (s == Screen.SETTINGS) View.VISIBLE else View.GONE
    }

    private fun openHome() = showScreen(Screen.HOME)

    private fun openTimer() {
        showScreen(Screen.TIMER)
        updateTimerPreview()
    }

    private fun openStatus() {
        showScreen(Screen.STATUS)
        refreshStatus()
    }

    private fun openSettings() {
        showScreen(Screen.SETTINGS)
        refreshDevices()
    }

    // =====================================================
    // Home
    // =====================================================

    private fun setupHome() {
        val p = b.pageHome
        p.btnMenu.setOnClickListener { showTopMenu(it) }
        p.btnPump.setOnClickListener { toggle("1") }
        p.btnSlow.setOnClickListener { toggle("2") }
        p.btnFast.setOnClickListener { toggle("3") }
        p.btnMode.setOnClickListener { toggle("4") }

        p.navHome.setOnClickListener { openHome() }
        p.navTimer.setOnClickListener { openTimer() }
        p.navStatus.setOnClickListener { openStatus() }
        p.navSettings.setOnClickListener { openSettings() }
    }

    private fun updateHome() {
        b.pageHome.tvTemp.text = "$temperature °C"
        b.pageHome.tvHumTime.text = if (isPersian) {
            "رطوبت: $humidity %     ساعت: $rtcTime"
        } else {
            "Humidity: $humidity %     Time: $rtcTime"
        }
    }

    // =====================================================
    // Fixed commands
    // =====================================================

    /** 1 = Pump, 2 = Slow, 3 = Fast, 4 = Auto/Manual, T = Timer */
    private fun toggle(command: String) {
        val allowed = setOf("1", "2", "3", "4", "T")
        if (command !in allowed) {
            addLog("!! Invalid fixed command: $command")
            return
        }
        sendCommand(command)
    }

    private fun refreshStatus() {
        addLog("Requesting full status...")
        sendCommand("s")
    }

    // =====================================================
    // Timer screen
    // =====================================================

    private fun numberAdapter(count: Int): ArrayAdapter<String> {
        val items = (0 until count).map { String.format(Locale.US, "%02d", it) }
        val adapter = ArrayAdapter(this, R.layout.spinner_item, items)
        adapter.setDropDownViewResource(R.layout.spinner_dropdown_item)
        return adapter
    }

    private fun setupTimer() {
        val p = b.pageTimer

        p.spOnHour.adapter = numberAdapter(24)
        p.spOnMinute.adapter = numberAdapter(60)
        p.spOffHour.adapter = numberAdapter(24)
        p.spOffMinute.adapter = numberAdapter(60)

        p.spOnHour.setSelection(7)
        p.spOnMinute.setSelection(30)
        p.spOffHour.setSelection(19)
        p.spOffMinute.setSelection(30)

        val listener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                updateTimerPreview()
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        p.spOnHour.onItemSelectedListener = listener
        p.spOnMinute.onItemSelectedListener = listener
        p.spOffHour.onItemSelectedListener = listener
        p.spOffMinute.onItemSelectedListener = listener

        p.btnSaveTimer.setOnClickListener { saveTimer() }
        p.btnToggleTimer.setOnClickListener { toggle("T") }
        p.navTimerBack.setOnClickListener { openHome() }

        updateTimerPreview()
    }

    private fun pickerString(hour: Spinner, minute: Spinner): String =
        String.format(Locale.US, "%02d%02d", hour.selectedItemPosition, minute.selectedItemPosition)

    private fun onTimeString() = pickerString(b.pageTimer.spOnHour, b.pageTimer.spOnMinute)

    private fun offTimeString() = pickerString(b.pageTimer.spOffHour, b.pageTimer.spOffMinute)

    private fun updateTimerPreview() {
        val on = onTimeString()
        val off = offTimeString()
        b.pageTimer.tvPreview.text = if (isPersian) {
            "روشن: ${on.substring(0, 2)}:${on.substring(2)} | خاموش: ${off.substring(0, 2)}:${off.substring(2)}"
        } else {
            "ON: ${on.substring(0, 2)}:${on.substring(2)} | OFF: ${off.substring(0, 2)}:${off.substring(2)}"
        }
    }

    private fun timerFeedback(msg: String) {
        b.pageTimer.tvTimerFeedback.text = msg
    }

    /** Send ONHHMM first, then OFFHHMM after 500 ms. */
    private fun saveTimer() {
        val on = onTimeString()
        val off = offTimeString()

        if (!validHhmm(on)) {
            timerFeedback(if (isPersian) "زمان روشن نامعتبر است." else "Invalid ON time.")
            return
        }
        if (!validHhmm(off)) {
            timerFeedback(if (isPersian) "زمان خاموش نامعتبر است." else "Invalid OFF time.")
            return
        }

        if (!sendCommand("ON$on")) {
            timerFeedback(if (isPersian) "خطا در ارسال؛ بلوتوث را بررسی کنید." else "Send failed; check Bluetooth.")
            return
        }
        timerFeedback(if (isPersian) "زمان روشن ارسال شد؛ در حال ارسال زمان خاموش..." else "ON sent; sending OFF...")

        ui.postDelayed({
            if (closing) return@postDelayed
            if (sendCommand("OFF$off")) {
                timerFeedback(if (isPersian) "تنظیمات ارسال شد." else "Settings sent.")
            } else {
                timerFeedback(if (isPersian) "ارسال زمان خاموش ناموفق بود." else "OFF send failed.")
            }
        }, 500)
    }

    private fun validHhmm(value: String): Boolean {
        if (value.length != 4 || !value.all { it in '0'..'9' }) return false
        val hour = value.substring(0, 2).toInt()
        val minute = value.substring(2).toInt()
        return hour in 0..23 && minute in 0..59
    }

    private fun setTimerState(value: String) {
        timerState = value
        refreshStatusLabels()
    }

    // =====================================================
    // Status screen + log
    // =====================================================

    private fun setupStatus() {
        b.pageStatus.btnRefresh.setOnClickListener { refreshStatus() }
        b.pageStatus.navStatusHome.setOnClickListener { openHome() }
        b.pageStatus.navStatusSettings.setOnClickListener { openSettings() }

        b.pageStatus.tvStTemp.text = "--.- C"
        b.pageStatus.tvStHum.text = "--.- %"
        b.pageStatus.tvStTime.text = "--:--"
    }

    /** Safe to call from any thread. */
    private fun addLog(message: String) {
        runOnUiThread {
            if (closing) return@runOnUiThread
            logLines.add(message)
            while (logLines.size > 250) logLines.removeAt(0)
            b.pageStatus.tvLog.text = logLines.joinToString("\n")
            b.pageStatus.svLog.post { b.pageStatus.svLog.fullScroll(View.FOCUS_DOWN) }
        }
    }

    private fun toast(msg: String) {
        runOnUiThread { Toast.makeText(this, msg, Toast.LENGTH_SHORT).show() }
    }

    // =====================================================
    // Settings screen (Bluetooth + RTC keypad)
    // =====================================================

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun setupSettings() {
        val p = b.pageSettings

        p.btnLoadDevices.setOnClickListener { refreshDevices() }
        p.btnConnect.setOnClickListener { connectSelected() }
        p.btnDisconnect.setOnClickListener { disconnect() }
        p.btnSendClock.setOnClickListener { clockKey("OK") }
        p.navSettingsBack.setOnClickListener { openHome() }

        buildKeypad()
        updateClockDisplay()
    }

    private fun buildKeypad() {
        val keys = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "DEL", "0", "CLR")
        val container = b.pageSettings.keypadContainer
        container.removeAllViews()

        var row: LinearLayout? = null
        for ((i, key) in keys.withIndex()) {
            if (i % 3 == 0) {
                val newRow = LinearLayout(this)
                newRow.orientation = LinearLayout.HORIZONTAL
                container.addView(
                    newRow,
                    LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    )
                )
                row = newRow
            }

            val btn = MaterialButton(this)
            btn.text = key
            btn.isAllCaps = false
            btn.textSize = 20f
            btn.minimumHeight = dp(54)
            btn.setTextColor(ContextCompat.getColor(this, R.color.text))
            btn.backgroundTintList = ColorStateList.valueOf(ContextCompat.getColor(this, R.color.btn_gray))
            btn.setOnClickListener { clockKey(key) }

            val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            lp.setMargins(dp(3), dp(2), dp(3), dp(2))
            row?.addView(btn, lp)
        }
    }

    // ---------- permissions (Android 12+ only) ----------

    private fun hasBtPermission(): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.S ||
            ContextCompat.checkSelfPermission(this, "android.permission.BLUETOOTH_CONNECT") ==
            PackageManager.PERMISSION_GRANTED

    private fun ensureBtPermission(): Boolean {
        if (hasBtPermission()) return true
        ActivityCompat.requestPermissions(this, arrayOf("android.permission.BLUETOOTH_CONNECT"), REQ_BT)
        return false
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_BT) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                refreshDevices()
            } else {
                addLog("!! Bluetooth permission denied.")
            }
        }
    }

    // ---------- paired devices ----------

    private fun refreshDevices() {
        val adapter = btAdapter
        if (adapter == null) {
            addLog("!! Bluetooth is not available on this device.")
            return
        }
        if (!adapter.isEnabled) {
            addLog("!! Bluetooth is off. Turn it on first.")
            return
        }
        if (!ensureBtPermission()) return

        try {
            val devices = (adapter.bondedDevices?.toList() ?: emptyList())
                .sortedBy { (it.name ?: "").lowercase(Locale.ROOT) }
            pairedDevices = devices

            val items = if (devices.isEmpty()) {
                listOf(if (isPersian) "دستگاه جفت‌شده‌ای یافت نشد" else "No paired device found")
            } else {
                devices.map { "${it.name ?: "Unnamed"} [${it.address}]" }
            }

            val spinner = b.pageSettings.spDevices
            val previous = spinner.selectedItem as? String
            val adapterItems = ArrayAdapter(this, R.layout.spinner_item, items)
            adapterItems.setDropDownViewResource(R.layout.spinner_dropdown_item)
            spinner.adapter = adapterItems
            val idx = if (previous != null) items.indexOf(previous) else -1
            spinner.setSelection(if (idx >= 0) idx else 0)

            if (devices.isEmpty()) addLog("No paired device found.")
            else addLog("${devices.size} paired device(s) found.")
        } catch (e: SecurityException) {
            addLog("!! Device list error: ${e.message ?: "permission denied"}")
        } catch (e: Exception) {
            addLog("!! Device list error: ${e.message ?: e.javaClass.simpleName}")
        }
    }

    // ---------- connect / disconnect ----------

    private fun connectSelected() {
        if (connected) {
            toast(if (isPersian) "قبلاً متصل شده است" else "Already connected")
            return
        }
        if (connecting) {
            toast(if (isPersian) "در حال اتصال، لطفاً صبر کنید..." else "Connecting, please wait...")
            return
        }
        val adapter = btAdapter
        if (adapter == null) {
            addLog("!! Bluetooth is not available on this device.")
            return
        }
        if (!adapter.isEnabled) {
            addLog("!! Turn Bluetooth on first.")
            toast(if (isPersian) "ابتدا بلوتوث را روشن کنید" else "Turn Bluetooth on first")
            return
        }
        if (!ensureBtPermission()) return

        val idx = b.pageSettings.spDevices.selectedItemPosition
        if (pairedDevices.isEmpty() || idx < 0 || idx >= pairedDevices.size) {
            addLog("!! Select a paired device first.")
            toast(if (isPersian) "ابتدا یک دستگاه انتخاب کنید" else "Select a paired device first")
            return
        }

        val device = pairedDevices[idx]
        connectedName = try {
            device.name ?: device.address
        } catch (e: SecurityException) {
            device.address
        }

        connecting = true
        updateConnectionUi()
        addLog("Requesting connection to ${device.address}")

        Thread { connectWorker(device, adapter) }.start()
    }

    /** Secure SPP socket first; HC-05 modules sometimes need the insecure one. */
    private fun openSocket(device: BluetoothDevice): BluetoothSocket {
        val first = device.createRfcommSocketToServiceRecord(sppUuid)
        try {
            first.connect()
            return first
        } catch (e: IOException) {
            try {
                first.close()
            } catch (e2: IOException) {
                // ignore
            }
        }

        val second = device.createInsecureRfcommSocketToServiceRecord(sppUuid)
        try {
            second.connect()
        } catch (e: IOException) {
            try {
                second.close()
            } catch (e2: IOException) {
                // ignore
            }
            throw e
        }
        return second
    }

    /** Runs on its own thread: connect, then keep reading lines until the link drops. */
    private fun connectWorker(device: BluetoothDevice, adapter: BluetoothAdapter) {
        try {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) {
                try {
                    adapter.cancelDiscovery()
                } catch (e: Exception) {
                    // ignore
                }
            }

            val ready = openSocket(device)

            socket = ready
            outStream = ready.outputStream
            connecting = false
            connected = true
            notifyState(true, "Connected: $connectedName")
            toast(if (isPersian) "متصل شد به $connectedName" else "Connected to $connectedName")
            
            // ✅ شروع ارسال خودکار دستور s به محض اتصال
            startAutoRefresh()

            readLoop(ready)
        } catch (e: Exception) {
            socket = null
            outStream = null
            connected = false
            connecting = false
            notifyState(false, "Connection failed: ${e.message ?: "could not connect"}")
            toast(
                if (isPersian) "اتصال ناموفق بود. مطمئن شوید HC-05 روشن و در دسترس است."
                else "Connection failed. Make sure the HC-05 is on and in range."
            )
        }
    }

    private fun readLoop(s: BluetoothSocket) {
        val buffer = ByteArrayOutputStream()
        val chunk = ByteArray(256)
        try {
            val input = s.inputStream
            while (!closing && socket === s) {
                val n = input.read(chunk)
                if (n < 0) throw IOException("Bluetooth link closed")
                for (i in 0 until n) {
                    val v = chunk[i].toInt()
                    if (v == 10) { // LF
                        val line = String(buffer.toByteArray(), Charsets.UTF_8).trimEnd('\r')
                        buffer.reset()
                        if (line.isNotEmpty()) onLine(line)
                    } else if (buffer.size() < 4096) {
                        buffer.write(v)
                    } else {
                        buffer.reset()
                    }
                }
            }
        } catch (e: Exception) {
            if (!closing && socket === s) {
                closeQuietly()
                notifyState(false, "Connection lost: ${e.message ?: "link closed"}")
                toast(if (isPersian) "اتصال قطع شد" else "Connection lost")
            }
        }
    }

    private fun disconnect() {
        if (!connected && !connecting) {
            toast(if (isPersian) "متصل نیست" else "Not connected")
            return
        }
        stopAutoRefresh() // ✅ توقف ارسال خودکار
        closeQuietly()
        notifyState(false, "Disconnected")
    }

    private fun closeQuietly() {
        val s = socket
        socket = null
        outStream = null
        connected = false
        connecting = false
        try {
            s?.close()
        } catch (e: IOException) {
            // ignore
        }
    }

    /** Connection state callback (any thread). */
    private fun notifyState(isConnected: Boolean, message: String) {
        runOnUiThread {
            if (closing) return@runOnUiThread
            addLog("** $message")
            updateConnectionUi()
        }
    }

    private fun updateConnectionUi() {
        val home = b.pageHome.tvConn
        val st = b.pageSettings.tvConnStatus

        when {
            connected -> {
                home.text = if (isPersian) "● متصل" else "● BT Connected"
                home.setTextColor(ContextCompat.getColor(this, R.color.green))
                st.text = if (isPersian) "وضعیت: متصل به $connectedName" else "Connection: Connected to $connectedName"
                st.setTextColor(ContextCompat.getColor(this, R.color.green))
            }
            connecting -> {
                home.text = if (isPersian) "● در حال اتصال..." else "● BT Connecting..."
                home.setTextColor(ContextCompat.getColor(this, R.color.yellow))
                st.text = if (isPersian) "وضعیت: در حال اتصال به $connectedName ..." else "Connection: Connecting to $connectedName ..."
                st.setTextColor(ContextCompat.getColor(this, R.color.yellow))
            }
            else -> {
                home.text = if (isPersian) "● قطع" else "● BT Disconnected"
                home.setTextColor(ContextCompat.getColor(this, R.color.orange))
                st.text = if (isPersian) "وضعیت: قطع" else "Connection: Disconnected"
                st.setTextColor(ContextCompat.getColor(this, R.color.orange))
            }
        }

        b.pageSettings.progressConnect.visibility = if (connecting) View.VISIBLE else View.GONE
        b.pageSettings.btnConnect.isEnabled = !connected && !connecting
        b.pageSettings.btnDisconnect.isEnabled = connected
    }

    // =====================================================
    // Auto-Refresh Timer (NEW)
    // =====================================================

    private val autoRefreshRunnable = object : Runnable {
        override fun run() {
            if (connected) {
                sendCommand("s")
                ui.postDelayed(this, 2000L) // ✅ هر 2 ثانیه یکبار
            }
        }
    }

    private fun startAutoRefresh() {
        if (!isAutoRefreshRunning) {
            isAutoRefreshRunning = true
            ui.post(autoRefreshRunnable)
        }
    }

    private fun stopAutoRefresh() {
        if (isAutoRefreshRunning) {
            isAutoRefreshRunning = false
            ui.removeCallbacks(autoRefreshRunnable)
        }
    }

    // =====================================================
    // Sending
    // =====================================================

    /** Sends [raw] followed by one LF. Returns false if it could not be queued. */
    private fun sendCommand(raw: String): Boolean {
        val command = raw.trim('\r', '\n')
        if (command.isEmpty()) {
            addLog("!! Empty command.")
            return false
        }

        val out = outStream
        if (!connected || out == null) {
            addLog("!! Bluetooth not connected; command not sent.")
            return false
        }

        addLog(">> $command")

        writer.execute {
            try {
                synchronized(writeLock) {
                    out.write((command + "\n").toByteArray(Charsets.UTF_8))
                    out.flush()
                }
            } catch (e: IOException) {
                addLog("!! Send error: ${e.message ?: "write failed"}")
                if (socket != null) {
                    closeQuietly()
                    notifyState(false, "Connection lost while sending")
                }
            }
        }
        return true
    }

    // =====================================================
    // Receiving
    // =====================================================

    /** Called from the Bluetooth thread. */
    private fun onLine(raw: String) {
        val line = raw.trim()
        if (line.isEmpty()) return

        val sensor = sensorRegex.matchEntire(line)
        runOnUiThread {
            if (closing) return@runOnUiThread
            if (sensor != null) {
                // periodic temperature/humidity line: show it but keep it out of the log
                applySensor(sensor)
            } else {
                addLog("<< $line")
                parseArduinoLine(line)
            }
        }
    }

    private fun applySensor(m: MatchResult) {
        temperature = m.groupValues[1]
        humidity = m.groupValues[2]
        b.pageStatus.tvStTemp.text = "$temperature C"
        b.pageStatus.tvStHum.text = "$humidity %"
        val tm = m.groupValues[3]
        if (tm.isNotEmpty()) setTimerState(if (tm == "1") "ON" else "OFF")
        updateHome()
    }

    private fun valueAfterColon(line: String): String = line.substringAfter(":", "").trim()

    /**
     * Parses status lines sent by the Arduino:
     *   Temp: 28.5 C | Humidity: 45.0 % | Time: 14:30 | Mode: Auto
     *   Pump: ON | Motor: Slow | Timer: ON
     * plus the short answers to commands (Pump ON, Motor Fast, Mode Auto, Timer OFF, Time 14:30).
     */
    private fun parseArduinoLine(line: String) {
        try {
            when {
                line.startsWith("Temp:") -> {
                    val v = valueAfterColon(line).replace(" C", "").replace("C", "").trim()
                    temperature = v
                    b.pageStatus.tvStTemp.text = "$v C"
                }
                line.startsWith("Humidity:") -> {
                    val v = valueAfterColon(line).replace("%", "").trim()
                    humidity = v
                    b.pageStatus.tvStHum.text = "$v %"
                }
                line.startsWith("Time:") -> {
                    rtcTime = valueAfterColon(line)
                    b.pageStatus.tvStTime.text = rtcTime
                }
                line.startsWith("Time ") -> {
                    rtcTime = line.substring(5).trim()
                    b.pageStatus.tvStTime.text = rtcTime
                }
                line.startsWith("Mode:") -> {
                    modeState = valueAfterColon(line)
                    refreshStatusLabels()
                }
                line.startsWith("Pump:") -> {
                    pumpState = valueAfterColon(line)
                    refreshStatusLabels()
                }
                line.startsWith("Motor:") -> {
                    motorState = valueAfterColon(line)
                    refreshStatusLabels()
                }
                line.startsWith("Timer:") -> setTimerState(valueAfterColon(line))
                line.startsWith("ON Time:") -> addLog("ON time: " + valueAfterColon(line))
                line.startsWith("OFF Time:") -> addLog("OFF time: " + valueAfterColon(line))

                // short answers to commands 1 / 2 / 3 / 4 / T
                line == "Pump ON" -> { pumpState = "ON"; refreshStatusLabels() }
                line == "Pump OFF" -> { pumpState = "OFF"; refreshStatusLabels() }
                line == "Motor Slow" -> { motorState = "Slow"; refreshStatusLabels() }
                line == "Motor Fast" -> { motorState = "Fast"; refreshStatusLabels() }
                line == "Motor OFF" -> { motorState = "OFF"; refreshStatusLabels() }
                line == "Mode Auto" -> { modeState = "Auto"; refreshStatusLabels() }
                line == "Mode Manual" -> { modeState = "Manual"; refreshStatusLabels() }
                line == "Timer ON" -> setTimerState("ON")
                line == "Timer OFF" -> setTimerState("OFF")
            }
            updateHome()
        } catch (e: Exception) {
            addLog("!! Parse error: ${e.message ?: e.javaClass.simpleName}")
        }
    }

    // =====================================================
    // RTC keypad  (1, 4, 3, 0, OK  ->  S1430)
    // =====================================================

    private fun clockKey(key: String) {
        when {
            key == "DEL" -> clockDigits = clockDigits.dropLast(1)
            key == "CLR" -> clockDigits = ""
            key == "OK" -> {
                sendRtcTime()
                return
            }
            key.length == 1 && key[0] in '0'..'9' && clockDigits.length < 4 -> clockDigits += key
        }

        updateClockDisplay()
        b.pageSettings.tvClockFeedback.text = if (isPersian) {
            if (clockDigits.isNotEmpty()) "${clockDigits.length} از ۴ رقم وارد شد"
            else "۴ رقم ساعت را وارد کنید"
        } else {
            if (clockDigits.isNotEmpty()) "${clockDigits.length} of 4 digits entered"
            else "Enter 4 digits for clock"
        }
    }

    private fun updateClockDisplay() {
        val digits = clockDigits.padEnd(4, '-')
        b.pageSettings.tvClockDisplay.text = digits.substring(0, 2) + ":" + digits.substring(2)
    }

    private fun sendRtcTime() {
        val fb = b.pageSettings.tvClockFeedback

        if (clockDigits.length != 4) {
            fb.text = if (isPersian) "دقیقاً ۴ رقم وارد کنید." else "Enter exactly 4 digits."
            return
        }
        if (!validHhmm(clockDigits)) {
            fb.text = if (isPersian) "ساعت نامعتبر است (بازه 00:00 تا 23:59)." else "Invalid time; range 00:00 - 23:59."
            return
        }

        if (sendCommand("S$clockDigits")) {
            val formatted = clockDigits.substring(0, 2) + ":" + clockDigits.substring(2)
            fb.text = if (isPersian) "دستور ساعت ارسال شد: $formatted" else "Clock command sent: $formatted"
        } else {
            fb.text = if (isPersian) "خطا در ارسال؛ بلوتوث را بررسی کنید." else "Send failed; check Bluetooth."
        }
    }

    companion object {
        private const val REQ_BT = 100
    }
}