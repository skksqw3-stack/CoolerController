package org.coolercontrol.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.ArrayAdapter
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.appcompat.app.AppCompatDelegate
import android.content.Context
import android.content.res.Configuration
import android.widget.PopupMenu
import java.util.Locale
import org.coolercontrol.app.databinding.ActivityMainBinding

/**
 * Cooler Control
 * Android App for Cooler Control with Arduino + HC-05
 * Direct Kotlin translation of main.py + cooler.kv
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var bluetooth: BluetoothManager
    private lateinit var onTimePicker: TimePickerHelper
    private lateinit var offTimePicker: TimePickerHelper
    private lateinit var rtcKeypad: NumericKeypadController

    private val mainHandler = Handler(Looper.getMainLooper())
    private val logLines = mutableListOf<String>()
    private var pairedDevices: List<Pair<String, String>> = emptyList()
    private var closing = false

    // State values matching HomeScreen & StatusScreen properties
    private var currentTemp = "--.-"
    private var currentHumidity = "--.-"
    private var currentRtcTime = "--:--"

    override fun attachBaseContext(newBase: Context) {
        val language = newBase.getSharedPreferences("cooler_prefs", Context.MODE_PRIVATE)
            .getString("language", "en") ?: "en"
        val locale = Locale(language)
        val config = Configuration(newBase.resources.configuration)
        config.setLocale(locale)
        super.attachBaseContext(newBase.createConfigurationContext(config))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        val prefs = getSharedPreferences("cooler_prefs", MODE_PRIVATE)
        AppCompatDelegate.setDefaultNightMode(
            if (prefs.getBoolean("night_mode", false))
                AppCompatDelegate.MODE_NIGHT_YES else AppCompatDelegate.MODE_NIGHT_NO
        )
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // ============ Bluetooth ============
        bluetooth = BluetoothManager(
            context = this,
            onLine = { line -> onBluetoothLine(line) },
            onState = { connected, message -> onBluetoothState(connected, message) }
        )

        setupNavigation()
        setupTopMenu()
        setupHomeControls()
        setupTimerControls()
        setupStatusControls()
        setupSettingsControls()

        // ============ Initial Setup ============
        mainHandler.postDelayed({
            checkPermissionsAndRefresh()
            addLog("App is ready.")
            addLog("Persian font loaded.")
        }, 300L)
    }

    override fun onDestroy() {
        closing = true
        try {
            bluetooth.disconnect(notify = false)
        } catch (_: Exception) {
        }
        super.onDestroy()
    }

    // =====================================================
    // Log (mirrors add_log in main.py)
    // =====================================================

    private fun addLog(message: String) {
        mainHandler.post {
            if (closing) return@post
            logLines.add(message)
            if (logLines.size > 250) {
                logLines.removeAt(0)
            }
            binding.tvLogOutput.text = logLines.joinToString("
")
            binding.scrollLog.post {
                binding.scrollLog.fullScroll(View.FOCUS_DOWN)
            }
        }
    }

    // =====================================================
    // Send Bluetooth Command (mirrors send_command in main.py)
    // =====================================================

    private fun sendCommand(rawCommand: String): Boolean {
        val command = rawCommand.trim('
', '
')
        if (command.isEmpty()) {
            addLog("!! Empty command.")
            return false
        }
        if (!bluetooth.isConnected()) {
            addLog("!! Bluetooth not connected; command not sent.")
            return false
        }

        addLog(">> $command")
        return try {
            bluetooth.send(command)
            true
        } catch (exc: Exception) {
            addLog("!! Send error: ${exc.message}")
            false
        }
    }

    // =====================================================
    // Fixed Commands (mirrors toggle, refresh_status, etc.)
    // =====================================================

    private fun toggle(command: String) {
        val allowedCommands = setOf("1", "2", "3", "4", "T")
        if (command !in allowedCommands) {
            addLog("!! Invalid fixed command: $command")
            return
        }
        sendCommand(command)
    }

    private fun refreshStatus() {
        addLog("Requesting full status...")
        sendCommand("s")
    }

    // =====================================================
    // Bluetooth Response Handler
    // =====================================================

    private fun onBluetoothLine(rawLine: String) {
        val line = rawLine.trim()
        if (line.isEmpty()) return

        addLog("<< $line")
        mainHandler.post {
            if (!closing) {
                parseArduinoLine(line)
            }
        }
    }

    private fun onBluetoothState(connected: Boolean, message: String) {
        mainHandler.post {
            if (closing) return@post

            val statusText = if (connected) getString(R.string.bt_connected) else getString(R.string.bt_disconnected)
            binding.tvHomeBtStatus.text = "● BT $statusText"
            binding.tvHomeBtStatus.setTextColor(
                ContextCompat.getColor(
                    this,
                    if (connected) R.color.status_connected else R.color.status_disconnected
                )
            )
            binding.tvSettingsConnection.text = "Connection: $statusText"
            addLog("** $message")
        }
    }

    // =====================================================
    // Parse Arduino Response (mirrors parse_arduino_line)
    // =====================================================

    private fun parseArduinoLine(rawLine: String) {
        val line = rawLine.trim()
        if (line.isEmpty()) return

        try {
            when {
                line.startsWith("Temp:") -> {
                    val value = line.substringAfter(":").replace(" C", "").replace("C", "").trim()
                    currentTemp = value
                    binding.tvHomeTemp.text = "$value °C"
                    binding.tvStatusTemp.text = "$value C"
                }
                line.startsWith("Humidity:") -> {
                    val value = line.substringAfter(":").replace("%", "").trim()
                    currentHumidity = value
                    binding.tvStatusHumidity.text = "$value %"
                    updateHomeSubInfo()
                }
                line.startsWith("Time:") -> {
                    val value = line.substringAfter(":").trim()
                    currentRtcTime = value
                    binding.tvStatusRtc.text = value
                    updateHomeSubInfo()
                }
                line.startsWith("Time ") -> {
                    val value = line.substring(5).trim()
                    currentRtcTime = value
                    binding.tvStatusRtc.text = value
                    updateHomeSubInfo()
                }
                line.startsWith("Mode:") -> {
                    val value = line.substringAfter(":").trim()
                    binding.tvStatusMode.text = "Mode: $value"
                }
                line.startsWith("Pump:") -> {
                    val value = line.substringAfter(":").trim()
                    binding.tvStatusPump.text = "Pump: $value"
                }
                line.startsWith("Motor:") -> {
                    val value = line.substringAfter(":").trim()
                    binding.tvStatusMotor.text = "Motor: $value"
                }
                line.startsWith("Timer:") -> {
                    val value = line.substringAfter(":").trim()
                    binding.tvStatusTimer.text = "Timer: $value"
                }
                line.startsWith("ON Time:") -> {
                    val value = line.substringAfter(":").trim()
                    addLog("ON time: $value")
                }
                line.startsWith("OFF Time:") -> {
                    val value = line.substringAfter(":").trim()
                    addLog("OFF time: $value")
                }
            }
        } catch (exc: Exception) {
            addLog("!! Parse error: ${exc.message}")
        }
    }

    private fun updateHomeSubInfo() {
        binding.tvHomeSubInfo.text = "Humidity: $currentHumidity %     Time: $currentRtcTime"
    }

    // =====================================================
    // Paired Bluetooth Devices
    // =====================================================

    private fun checkPermissionsAndRefresh() {
        // Android 4.4-11: BLUETOOTH and BLUETOOTH_ADMIN are granted at install time.
        // Android 12+: ask for CONNECT/SCAN at runtime.
        if (Build.VERSION.SDK_INT >= 31) {
            val needed = ArrayList<String>()
            if (checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                needed.add(Manifest.permission.BLUETOOTH_CONNECT)
            }
            if (checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) {
                needed.add(Manifest.permission.BLUETOOTH_SCAN)
            }
            if (needed.isNotEmpty()) {
                requestPermissions(needed.toTypedArray(), 410)
                return
            }
        }
        refreshDevices()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 410) {
            if (grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }) {
                refreshDevices()
            } else {
                addLog("Bluetooth permission denied.")
            }
        }
    }

    private fun refreshDevices() {
        try {
            val devices = bluetooth.getPairedDevices()
            pairedDevices = devices

            val labels = if (devices.isNotEmpty()) {
                devices.map { (name, address) -> "$name [$address]" }
            } else {
                listOf("No paired device found")
            }

            val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, labels).apply {
                setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            }
            binding.spinnerDevices.adapter = adapter

            if (devices.isNotEmpty()) {
                addLog("${devices.size} paired device(s) found.")
            } else {
                addLog("No paired device found.")
            }
        } catch (exc: Exception) {
            addLog("!! Device list error: ${exc.message}")
        }
    }

    private fun connectSelected() {
        try {
            val pos = binding.spinnerDevices.selectedItemPosition
            if (pairedDevices.isEmpty() || pos < 0 || pos >= pairedDevices.size) {
                binding.tvClockFeedback.text = "Select a paired device first."
                return
            }

            val (_, address) = pairedDevices[pos]
            binding.tvClockFeedback.text = "Connecting..."
            addLog("Requesting connection to $address")

            Thread {
                try {
                    bluetooth.connect(address)
                } catch (exc: Exception) {
                    addLog("!! Connection failed: ${exc.message}")
                }
            }.apply {
                isDaemon = true
                start()
            }
        } catch (exc: Exception) {
            addLog("!! Connect start error: ${exc.message}")
        }
    }

    // =====================================================
    // Screen Setup & Controls
    // =====================================================

    private fun setupTopMenu() {
        binding.btnMenu.setOnClickListener { anchor ->
            val popup = PopupMenu(this, anchor)
            popup.menu.add(0, 1, 0, getString(R.string.menu_day_mode))
            popup.menu.add(0, 2, 1, getString(R.string.menu_night_mode))
            popup.menu.add(0, 3, 2, getString(R.string.menu_persian))
            popup.menu.add(0, 4, 3, getString(R.string.menu_english))
            popup.setOnMenuItemClickListener { item ->
                val prefs = getSharedPreferences("cooler_prefs", MODE_PRIVATE)
                when (item.itemId) {
                    1 -> {
                        prefs.edit().putBoolean("night_mode", false).apply()
                        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
                        true
                    }
                    2 -> {
                        prefs.edit().putBoolean("night_mode", true).apply()
                        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
                        true
                    }
                    3 -> {
                        prefs.edit().putString("language", "fa").apply()
                        recreate()
                        true
                    }
                    4 -> {
                        prefs.edit().putString("language", "en").apply()
                        recreate()
                        true
                    }
                    else -> false
                }
            }
            popup.show()
        }
    }

    private fun setupNavigation() {
        binding.navHome.setOnClickListener { openHome() }
        binding.navTimer.setOnClickListener { openTimer() }
        binding.navStatus.setOnClickListener { openStatus() }
        binding.navSettings.setOnClickListener { openSettings() }

        binding.btnTimerBackHome.setOnClickListener { openHome() }
        binding.btnSettingsBackHome.setOnClickListener { openHome() }
    }

    private fun openHome() {
        showScreen(binding.screenHome)
    }

    private fun openTimer() {
        showScreen(binding.screenTimer)
        updateTimerPreview()
    }

    private fun openStatus() {
        showScreen(binding.screenStatus)
        refreshStatus()
    }

    private fun openSettings() {
        showScreen(binding.screenSettings)
        refreshDevices()
    }

    private fun showScreen(target: View) {
        binding.screenHome.visibility = if (target == binding.screenHome) View.VISIBLE else View.GONE
        binding.screenTimer.visibility = if (target == binding.screenTimer) View.VISIBLE else View.GONE
        binding.screenStatus.visibility = if (target == binding.screenStatus) View.VISIBLE else View.GONE
        binding.screenSettings.visibility = if (target == binding.screenSettings) View.VISIBLE else View.GONE
    }

    private fun setupHomeControls() {
        binding.btnPump.setOnClickListener { toggle("1") }
        binding.btnSlowMotor.setOnClickListener { toggle("2") }
        binding.btnFastMotor.setOnClickListener { toggle("3") }
        binding.btnMode.setOnClickListener { toggle("4") }
    }

    private fun setupTimerControls() {
        onTimePicker = TimePickerHelper(
            context = this,
            hourSpinner = binding.spinnerOnHour,
            minuteSpinner = binding.spinnerOnMinute,
            initialHour = 7,
            initialMinute = 30,
            onTimeChange = { updateTimerPreview() }
        )

        offTimePicker = TimePickerHelper(
            context = this,
            hourSpinner = binding.spinnerOffHour,
            minuteSpinner = binding.spinnerOffMinute,
            initialHour = 19,
            initialMinute = 30,
            onTimeChange = { updateTimerPreview() }
        )

        binding.btnSaveTimer.setOnClickListener { saveTimer() }
        binding.btnToggleTimer.setOnClickListener { toggle("T") }
    }

    private fun updateTimerPreview() {
        val onTime = onTimePicker.getTimeString()
        val offTime = offTimePicker.getTimeString()
        binding.tvTimerPreview.text =
            "ON: ${onTime.substring(0, 2)}:${onTime.substring(2)} | OFF: ${offTime.substring(0, 2)}:${offTime.substring(2)}"
    }

    private fun saveTimer() {
        try {
            val onTime = onTimePicker.getTimeString()
            val offTime = offTimePicker.getTimeString()

            if (!validHhmm(onTime)) {
                binding.tvTimerFeedback.text = "Invalid ON time."
                return
            }
            if (!validHhmm(offTime)) {
                binding.tvTimerFeedback.text = "Invalid OFF time."
                return
            }

            val onCommand = "ON$onTime"
            val offCommand = "OFF$offTime"

            if (!sendCommand(onCommand)) {
                binding.tvTimerFeedback.text = "Send failed; check Bluetooth."
                return
            }

            binding.tvTimerFeedback.text = "ON sent; sending OFF..."

            mainHandler.postDelayed({
                if (sendCommand(offCommand)) {
                    binding.tvTimerFeedback.text = "Settings sent."
                } else {
                    binding.tvTimerFeedback.text = "OFF send failed."
                }
            }, 500L)
        } catch (exc: Exception) {
            addLog("!! Timer set error: ${exc.message}")
        }
    }

    private fun validHhmm(value: String): Boolean {
        if (value.length != 4 || value.any { !it.isDigit() }) return false
        val hour = value.substring(0, 2).toInt()
        val minute = value.substring(2, 4).toInt()
        return (hour in 0..23) && (minute in 0..59)
    }

    private fun setupStatusControls() {
        binding.btnRefreshStatus.setOnClickListener { refreshStatus() }
    }

    private fun setupSettingsControls() {
        binding.btnLoadDevices.setOnClickListener { refreshDevices() }
        binding.btnConnectBt.setOnClickListener { connectSelected() }
        binding.btnDisconnectBt.setOnClickListener {
            try {
                bluetooth.disconnect(notify = true)
            } catch (exc: Exception) {
                addLog("!! Disconnect error: ${exc.message}")
            }
        }

        val digitButtons = mapOf(
            "0" to binding.key0, "1" to binding.key1, "2" to binding.key2,
            "3" to binding.key3, "4" to binding.key4, "5" to binding.key5,
            "6" to binding.key6, "7" to binding.key7, "8" to binding.key8,
            "9" to binding.key9
        )

        rtcKeypad = NumericKeypadController(
            display = binding.tvClockDisplay,
            digitButtons = digitButtons,
            delButton = binding.keyDel,
            clrButton = binding.keyClr,
            confirmButton = binding.btnSendClock,
            onChange = { digits ->
                binding.tvClockFeedback.text = if (digits.isNotEmpty()) {
                    "${digits.length} of 4 digits entered"
                } else {
                    getString(R.string.enter_4_digits)
                }
            },
            onConfirm = { digits ->
                sendRtcTime(digits)
            }
        )
    }

    private fun sendRtcTime(digits: String) {
        if (digits.length != 4) {
            binding.tvClockFeedback.text = "Enter exactly 4 digits."
            return
        }
        if (!validHhmm(digits)) {
            binding.tvClockFeedback.text = "Invalid time; range 00:00 - 23:59."
            return
        }

        val command = "S$digits"
        if (sendCommand(command)) {
            binding.tvClockFeedback.text =
                "Clock command sent: ${digits.substring(0, 2)}:${digits.substring(2)}"
        } else {
            binding.tvClockFeedback.text = "Send failed; check Bluetooth."
        }
    }
}
