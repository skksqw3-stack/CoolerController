package com.example.cooler

import android.Manifest
import android.annotation.SuppressLint
import android.app.TimePickerDialog
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.gridlayout.widget.GridLayout
import com.example.cooler.databinding.ActivityMainBinding
import com.google.android.material.button.MaterialButton
import java.io.IOException
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import java.util.concurrent.Executors

@SuppressLint("MissingPermission")
class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding

    // UUID استاندارد SPP برای ماژول HC-05
    private val sppUuid: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

    // API 19-safe: BluetoothAdapter.getDefaultAdapter() exists on Android 4.4.
    private val btAdapter: BluetoothAdapter? by lazy {
        BluetoothAdapter.getDefaultAdapter()
    }

    private var socket: BluetoothSocket? = null
    private var outStream: OutputStream? = null
    @Volatile private var connected = false
    private var devices: List<BluetoothDevice> = emptyList()

    // یک رشته جدا برای نوشتن، تا رابط کاربری قفل نشود
    private val io = Executors.newSingleThreadExecutor()
    private val timeFmt = SimpleDateFormat("HH:mm:ss", Locale.US)
    private val rtcDigits = StringBuilder()


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        setupNavigation()
        setupHome()
        setupTimer()
        setupStatus()
        setupSettings()
        updateConnectionUi()

        ensurePermissionThenLoad()
    }

    // ---------------------------------------------------------------- ناوبری
    private fun setupNavigation() {
        showPage(R.id.nav_home)
        b.bottomNav.setOnItemSelectedListener {
            showPage(it.itemId)
            true
        }
    }

    private fun showPage(id: Int) {
        b.pageHome.root.visibility = if (id == R.id.nav_home) View.VISIBLE else View.GONE
        b.pageTimer.root.visibility = if (id == R.id.nav_timer) View.VISIBLE else View.GONE
        b.pageStatus.root.visibility = if (id == R.id.nav_status) View.VISIBLE else View.GONE
        b.pageSettings.root.visibility = if (id == R.id.nav_settings) View.VISIBLE else View.GONE
    }

    // ---------------------------------------------------------------- خانه
    private fun setupHome() {
        b.pageHome.btnPump.setOnClickListener { send("1") }
        b.pageHome.btnSlow.setOnClickListener { send("2") }
        b.pageHome.btnFast.setOnClickListener { send("3") }
        b.pageHome.btnAuto.setOnClickListener { send("4") }
    }

    // ---------------------------------------------------------------- تایمر
    private fun setupTimer() {
        b.pageTimer.btnSetOn.setOnClickListener { pickTime("ON", b.pageTimer.tvOnTime) }
        b.pageTimer.btnSetOff.setOnClickListener { pickTime("OFF", b.pageTimer.tvOffTime) }
    }

    private fun pickTime(prefix: String, label: TextView) {
        TimePickerDialog(this, { _, h, m ->
            label.text = String.format(Locale.US, "%02d:%02d", h, m)
            send(prefix + String.format(Locale.US, "%02d%02d", h, m))
        }, 7, 0, true).show()
    }

    // ---------------------------------------------------------------- وضعیت
    private fun setupStatus() {
        b.pageStatus.btnClearLog.setOnClickListener { b.pageStatus.tvLog.text = "" }
    }

    private fun log(line: String) {
        runOnUiThread {
            b.pageStatus.tvLog.append("[${timeFmt.format(Date())}] $line\n")
            b.pageStatus.scrollLog.post { b.pageStatus.scrollLog.fullScroll(View.FOCUS_DOWN) }
        }
    }

    // ---------------------------------------------------------------- تنظیمات
    private fun setupSettings() {
        b.pageSettings.btnRefresh.setOnClickListener { ensurePermissionThenLoad() }
        b.pageSettings.btnConnect.setOnClickListener { connect() }
        b.pageSettings.btnDisconnect.setOnClickListener { disconnect(true) }
        buildKeypad()
        b.pageSettings.btnSendRtc.setOnClickListener {
            if (rtcDigits.length != 4) {
                toast("چهار رقم HHMM وارد کنید"); return@setOnClickListener
            }
            val h = rtcDigits.substring(0, 2).toInt()
            val m = rtcDigits.substring(2, 4).toInt()
            if (h > 23 || m > 59) {
                toast("ساعت نامعتبر است"); return@setOnClickListener
            }
            send("S$rtcDigits")
        }
    }

    private fun buildKeypad() {
        val keys = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "C", "0", "⌫")
        val grid: GridLayout = b.pageSettings.gridKeypad
        for (k in keys) {
            val btn = MaterialButton(this).apply {
                text = k
                textSize = 20f
                layoutParams = GridLayout.LayoutParams(
                    GridLayout.spec(GridLayout.UNDEFINED, 1f),
                    GridLayout.spec(GridLayout.UNDEFINED, 1f)
                ).apply {
                    width = 0
                    setMargins(6, 6, 6, 6)
                }
                setOnClickListener { onKey(k) }
            }
            grid.addView(btn)
        }
    }

    private fun onKey(k: String) {
        when (k) {
            "C" -> rtcDigits.clear()
            "⌫" -> if (rtcDigits.isNotEmpty()) rtcDigits.deleteCharAt(rtcDigits.length - 1)
            else -> if (rtcDigits.length < 4) rtcDigits.append(k)
        }
        val p = rtcDigits.toString().padEnd(4, '_')
        b.pageSettings.tvRtc.text = p.substring(0, 2) + ":" + p.substring(2, 4)
    }

    // ---------------------------------------------------------------- مجوز و لیست دستگاه‌ها
    private fun hasBtPermission(): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.S ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) ==
            PackageManager.PERMISSION_GRANTED

    private fun ensurePermissionThenLoad() {
        if (hasBtPermission()) loadDevices()
        else if (Build.VERSION.SDK_INT >= 23) {
            requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), REQUEST_BT_PERMISSION)
        } else {
            // Android 4.4 grants BLUETOOTH at install time; no runtime dialog exists.
            loadDevices()
        }
    }

    private fun loadDevices() {
        val adapter = btAdapter
        if (adapter == null) {
            toast("این گوشی بلوتوث ندارد"); return
        }
        if (!adapter.isEnabled) {
            toast("لطفاً بلوتوث را روشن کنید"); return
        }
        try {
            devices = adapter.bondedDevices?.toList() ?: emptyList()
            val names = devices.map { "${it.name ?: "بدون نام"}  (${it.address})" }
            b.pageSettings.spinnerDevices.adapter =
                ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names)
            if (devices.isEmpty()) toast("دستگاه جفت‌شده‌ای نیست. اول HC-05 را در تنظیمات بلوتوث گوشی جفت کنید")
        } catch (e: SecurityException) {
            devices = emptyList()
            b.pageSettings.spinnerDevices.adapter =
                ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, emptyList<String>())
            log("مجوز بلوتوث در برنامه نصب‌شده وجود ندارد. برنامه را حذف و APK جدید را دوباره نصب کنید. ${e.message ?: ""}")
            toast("مجوز بلوتوث موجود نیست؛ APK جدید را نصب کنید")
        }
    }

    // ---------------------------------------------------------------- بلوتوث
    private fun connect() {
        if (connected) {
            toast("از قبل متصل هستید"); return
        }
        if (!hasBtPermission()) {
            ensurePermissionThenLoad(); return
        }
        val idx = b.pageSettings.spinnerDevices.selectedItemPosition
        if (idx < 0 || idx >= devices.size) {
            toast("یک دستگاه انتخاب کنید"); return
        }
        val device = devices[idx]
        log("در حال اتصال به ${device.address} ...")

        Thread {
            try {
                // برای اتصال به دستگاه جفت‌شده، cancelDiscovery لازم نیست.
                // در Android 12+ این فراخوانی به BLUETOOTH_SCAN نیاز دارد و
                // در صورت نداشتن مجوز می‌تواند SecurityException ایجاد کند.
                // فقط در Android 11 و پایین‌تر (BLUETOOTH_ADMIN) لغو جستجو لازم/ممکن است
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) {
                    try { btAdapter?.cancelDiscovery() } catch (e: Exception) { }
                }
                val s = device.createRfcommSocketToServiceRecord(sppUuid)
                s.connect()
                socket = s
                outStream = s.outputStream
                connected = true
                log("اتصال برقرار شد")
                runOnUiThread { updateConnectionUi() }
                readLoop(s)
            } catch (e: SecurityException) {
                log("مجوز بلوتوث کافی نیست: ${e.message ?: "اجازه دسترسی داده نشد"}")
                closeQuietly()
                runOnUiThread { updateConnectionUi() }
            } catch (e: IOException) {
                log("خطا در اتصال: ${e.message ?: "ارتباط برقرار نشد"}")
                closeQuietly()
                runOnUiThread { updateConnectionUi() }
            } catch (e: Exception) {
                log("خطای غیرمنتظره در اتصال: ${e.message ?: e.javaClass.simpleName}")
                closeQuietly()
                runOnUiThread { updateConnectionUi() }
            }
        }.start()
    }

    /** خواندن خط‌به‌خط داده‌های دریافتی (پایان خط با \n یا \r\n) */
    private fun readLoop(s: BluetoothSocket) {
        try {
            val reader = s.inputStream.bufferedReader()
            while (true) {
                val line = reader.readLine() ?: break
                val text = line.trim()
                if (text.isNotEmpty()) {
                    log("← $text")
                    parseSensor(text)
                }
            }
        } catch (e: IOException) {
            // اتصال قطع شد
        }
        if (connected) {
            log("اتصال قطع شد")
            closeQuietly()
            runOnUiThread { updateConnectionUi() }
        }
    }

    /**
     * فرض: دستگاه چیزی شبیه  T:28.5,H:40  یا  T28.5 H40  می‌فرستد.
     * اگر قالب شما فرق دارد این تابع را تغییر دهید.
     */
    private fun parseSensor(line: String) {
        val t = Regex("""[Tt]\s*[:=]?\s*(-?\d+(?:\.\d+)?)""").find(line)?.groupValues?.get(1)
        val h = Regex("""[Hh]\s*[:=]?\s*(\d+(?:\.\d+)?)""").find(line)?.groupValues?.get(1)
        runOnUiThread {
            if (t != null) b.pageHome.tvTemp.text = "دما: $t °C"
            if (h != null) b.pageHome.tvHum.text = "رطوبت: $h %"
        }
    }

    private fun send(cmd: String) {
        if (!connected) {
            toast("ابتدا از تنظیمات به دستگاه وصل شوید"); return
        }
        io.execute {
            try {
                outStream?.write((cmd + "\n").toByteArray())
                outStream?.flush()
                log("→ $cmd")
            } catch (e: IOException) {
                log("خطا در ارسال: ${e.message}")
                closeQuietly()
                runOnUiThread { updateConnectionUi() }
            }
        }
    }

    private fun disconnect(manual: Boolean) {
        if (manual && connected) log("اتصال قطع شد (دستی)")
        closeQuietly()
        updateConnectionUi()
    }

    private fun closeQuietly() {
        connected = false
        try { outStream?.close() } catch (e: Exception) {}
        try { socket?.close() } catch (e: Exception) {}
        outStream = null
        socket = null
    }

    private fun updateConnectionUi() {
        val tv = b.pageHome.tvConn
        if (connected) {
            tv.text = "وضعیت اتصال: متصل ✔"
            tv.setTextColor(Color.parseColor("#C8E6C9"))
        } else {
            tv.text = "وضعیت اتصال: قطع"
            tv.setTextColor(Color.parseColor("#E3F2FD"))
        }
    }

    private fun toast(msg: String) =
        runOnUiThread { Toast.makeText(this, msg, Toast.LENGTH_SHORT).show() }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_BT_PERMISSION) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                loadDevices()
            } else {
                toast("برای اتصال بلوتوث باید مجوز داده شود")
            }
        }
    }

    override fun onDestroy() {
        closeQuietly()
        io.shutdown()
        super.onDestroy()
    }

    companion object {
        private const val REQUEST_BT_PERMISSION = 410
    }
}
