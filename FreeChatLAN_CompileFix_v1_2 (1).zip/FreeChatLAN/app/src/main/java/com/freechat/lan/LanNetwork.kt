package com.freechat.lan

import android.content.Context
import android.net.wifi.WifiManager
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.PrintWriter
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.Inet4Address
import java.net.InetAddress
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.util.Collections
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList
import kotlin.concurrent.thread

/**
 * Star-topology LAN messenger.
 * The host phone runs this TCP server and automatically routes every message.
 * Other phones connect once and send messages directly to the server socket.
 * No user has to manually forward or approve messages.
 * Message history is memory-only; this class never writes chat data to disk.
 */
class LanNetwork(private val context: Context, private val listener: Listener) {
    interface Listener {
        fun onStatus(message: String)
        fun onMessage(message: ChatMessage)
        fun onPeerCount(count: Int)
        fun onError(message: String)
    }

    val deviceId: String = UUID.randomUUID().toString()
    private val peers = CopyOnWriteArrayList<Peer>()
    private val seenMessageIds = Collections.newSetFromMap(ConcurrentHashMap<String, Boolean>())

    @Volatile private var server: ServerSocket? = null
    @Volatile private var client: Socket? = null
    @Volatile private var clientWriter: PrintWriter? = null
    @Volatile private var discoverySocket: DatagramSocket? = null
    @Volatile private var running = false
    @Volatile private var hosting = false
    private var multicastLock: WifiManager.MulticastLock? = null
    @Volatile private var myName = "کاربر"

    private data class Peer(
        val socket: Socket,
        val writer: PrintWriter,
        @Volatile var id: String = "",
        @Volatile var name: String = "کاربر"
    )

    /** Start the automatic message router on the phone that has the hotspot enabled. */
    fun startHost(name: String) {
        stop()
        myName = name
        running = true
        hosting = true
        acquireMulticastLock()
        thread(name = "freechat-server") {
            try {
                val ss = ServerSocket(PORT)
                server = ss
                val ip = localIpv4() ?: "IP نامشخص"
                listener.onStatus("سرور خودکار فعال است • $ip:$PORT")
                startDiscoveryResponder()
                while (running) {
                    val socket = ss.accept()
                    socket.tcpNoDelay = true
                    socket.keepAlive = true
                    val peer = Peer(socket, PrintWriter(socket.getOutputStream(), true))
                    peers.add(peer)
                    publishPeerCount()
                    thread(name = "freechat-peer") { readPeer(peer) }
                }
            } catch (e: Exception) {
                if (running) listener.onError("سرور اجرا نشد: ${e.message}")
            }
        }
    }

    private fun startDiscoveryResponder() {
        thread(name = "freechat-discovery-server") {
            var socket: DatagramSocket? = null
            try {
                val discovery = DatagramSocket(DISCOVERY_PORT, InetAddress.getByName("0.0.0.0"))
                socket = discovery
                discovery.broadcast = true
                discoverySocket = discovery
                val buffer = ByteArray(256)
                while (running) {
                    val packet = DatagramPacket(buffer, buffer.size)
                    discovery.receive(packet)
                    val request = String(packet.data, packet.offset, packet.length, Charsets.UTF_8)
                    if (request == DISCOVER_TOKEN) {
                        val ip = localIpv4() ?: packet.address.hostAddress
                        val response = JSONObject()
                            .put("type", "HOST")
                            .put("name", myName)
                            .put("ip", ip)
                            .put("port", PORT)
                            .toString().toByteArray(Charsets.UTF_8)
                        discovery.send(DatagramPacket(response, response.size, packet.address, packet.port))
                    }
                }
            } catch (_: Exception) {
                // Closing this socket during stop() is expected.
            } finally {
                try { socket?.close() } catch (_: Exception) { }
            }
        }
    }

    /** Broadcast discovery request; manual IP entry remains available as a fallback. */
    fun discoverHost(callback: (String, String) -> Unit) {
        thread(name = "freechat-discovery-client") {
            var found = false
            try {
                acquireMulticastLock()
                DatagramSocket().use { ds ->
                    ds.broadcast = true
                    ds.soTimeout = 1800
                    val bytes = DISCOVER_TOKEN.toByteArray(Charsets.UTF_8)
                    ds.send(DatagramPacket(bytes, bytes.size, InetAddress.getByName("255.255.255.255"), DISCOVERY_PORT))
                    val buffer = ByteArray(1024)
                    try {
                        while (true) {
                            val packet = DatagramPacket(buffer, buffer.size)
                            ds.receive(packet)
                            val obj = JSONObject(String(packet.data, packet.offset, packet.length, Charsets.UTF_8))
                            val ip = obj.optString("ip", packet.address.hostAddress)
                            callback(ip, obj.optString("name", "FreeChat host"))
                            found = true
                        }
                    } catch (_: java.net.SocketTimeoutException) { }
                }
            } catch (e: Exception) {
                listener.onError("جست‌وجوی میزبان ناموفق بود: ${e.message}")
            }
            if (!found) listener.onStatus("میزبانی پیدا نشد؛ IP میزبان را دستی وارد کن")
        }
    }

    /** Connect a client phone to the host. The host routes messages automatically. */
    fun connect(ip: String, name: String) {
        stop()
        myName = name
        running = true
        hosting = false
        acquireMulticastLock()
        thread(name = "freechat-client") {
            try {
                val socket = Socket(ip, PORT)
                socket.tcpNoDelay = true
                socket.keepAlive = true
                client = socket
                val writer = PrintWriter(socket.getOutputStream(), true)
                clientWriter = writer
                sendJson(writer, JSONObject()
                    .put("type", "HELLO")
                    .put("id", deviceId)
                    .put("name", myName))
                listener.onStatus("در حال اتصال به $ip ...")
                val reader = BufferedReader(InputStreamReader(socket.getInputStream(), Charsets.UTF_8))
                while (running) {
                    val line = reader.readLine() ?: break
                    handleClientPacket(JSONObject(line))
                }
                if (running) listener.onStatus("ارتباط با میزبان قطع شد")
            } catch (e: Exception) {
                if (running) listener.onError("اتصال برقرار نشد: ${e.message}")
            }
        }
    }

    private fun readPeer(peer: Peer) {
        try {
            val reader = BufferedReader(InputStreamReader(peer.socket.getInputStream(), Charsets.UTF_8))
            while (running) {
                val line = reader.readLine() ?: break
                val obj = JSONObject(line)
                when (obj.optString("type")) {
                    "HELLO" -> {
                        peer.id = obj.optString("id")
                        peer.name = obj.optString("name", "کاربر")
                        sendToPeer(peer, JSONObject()
                            .put("type", "WELCOME")
                            .put("id", deviceId)
                            .put("name", myName)
                            .put("online", peers.size))
                        broadcastSystem("${peer.name} به گفتگو پیوست")
                        publishPeerCount()
                    }
                    "MESSAGE" -> {
                        val message = ChatMessage.fromJson(obj)
                        // Deduplicate message IDs so accidental retransmission cannot create loops.
                        if (rememberMessage(message.id)) {
                            listener.onMessage(message)
                            routeMessage(message, peer)
                        }
                    }
                    "PING" -> sendToPeer(peer, JSONObject().put("type", "PONG"))
                }
            }
        } catch (_: Exception) {
            // A disconnected client is removed below.
        } finally {
            peers.remove(peer)
            try { peer.socket.close() } catch (_: Exception) { }
            if (running && peer.name != "کاربر") broadcastSystem("${peer.name} از گفتگو خارج شد")
            publishPeerCount()
        }
    }

    private fun handleClientPacket(obj: JSONObject) {
        when (obj.optString("type")) {
            "MESSAGE" -> {
                val message = ChatMessage.fromJson(obj)
                if (rememberMessage(message.id)) listener.onMessage(message)
            }
            "WELCOME" -> listener.onStatus("متصل به سرور ${obj.optString("name")} • کاربران: ${obj.optInt("online", 1)}")
            "SYSTEM" -> listener.onStatus(obj.optString("text"))
            "PONG" -> { }
        }
    }

    /** Host's own messages are routed to every connected client automatically. */
    fun sendText(text: String, targetId: String = "*") {
        val clean = text.trim()
        if (clean.isEmpty()) return
        val message = ChatMessage(UUID.randomUUID().toString(), deviceId, myName, clean,
            System.currentTimeMillis(), targetId)
        rememberMessage(message.id)
        listener.onMessage(message)
        val json = message.toJson()
        if (hosting) {
            routeMessage(message, null)
        } else {
            val writer = clientWriter
            if (writer == null) listener.onError("ابتدا به میزبان متصل شو")
            else if (!sendJson(writer, json)) listener.onError("ارسال پیام ناموفق بود")
        }
    }

    /** Server-side routing. A target of * means group broadcast; otherwise direct message. */
    private fun routeMessage(message: ChatMessage, origin: Peer?) {
        val json = message.toJson()
        peers.forEach { peer ->
            if (peer !== origin && (message.targetId == "*" || peer.id == message.targetId)) {
                sendToPeer(peer, json)
            }
        }
    }

    private fun broadcastSystem(text: String) {
        val packet = JSONObject().put("type", "SYSTEM").put("text", text)
        peers.forEach { sendToPeer(it, packet) }
    }

    private fun sendToPeer(peer: Peer, obj: JSONObject) {
        if (!sendJson(peer.writer, obj)) {
            try { peer.socket.close() } catch (_: Exception) { }
        }
    }

    private fun sendJson(writer: PrintWriter, obj: JSONObject): Boolean {
        return try {
            synchronized(writer) {
                writer.println(obj.toString())
                !writer.checkError()
            }
        } catch (_: Exception) { false }
    }

    private fun rememberMessage(id: String): Boolean {
        if (id.isEmpty()) return false
        return seenMessageIds.add(id)
    }

    private fun publishPeerCount() {
        listener.onPeerCount(peers.size)
    }

    fun stop() {
        running = false
        hosting = false
        try { server?.close() } catch (_: Exception) { }
        server = null
        try { client?.close() } catch (_: Exception) { }
        client = null
        clientWriter = null
        try { discoverySocket?.close() } catch (_: Exception) { }
        discoverySocket = null
        peers.forEach { try { it.socket.close() } catch (_: Exception) { } }
        peers.clear()
        seenMessageIds.clear()
        listener.onPeerCount(0)
        try { multicastLock?.release() } catch (_: Exception) { }
        multicastLock = null
    }

    private fun acquireMulticastLock() {
        try {
            if (multicastLock == null || multicastLock?.isHeld != true) {
                val wifi = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
                multicastLock = wifi.createMulticastLock("FreeChatLAN").apply {
                    setReferenceCounted(false)
                    acquire()
                }
            }
        } catch (_: Exception) { }
    }

    private fun localIpv4(): String? = try {
        val interfaces = Collections.list(NetworkInterface.getNetworkInterfaces())
            .filter { it.isUp && !it.isLoopback }
        // Prefer Wi-Fi / hotspot interfaces; avoid accidentally advertising a mobile-data IP.
        val wifiFirst = interfaces.sortedBy {
            val n = it.name.toLowerCase(java.util.Locale.US)
            if (n.contains("wlan") || n.contains("wifi") || n.contains("ap")) 0 else 1
        }
        val addresses = wifiFirst.flatMap { Collections.list(it.inetAddresses) }
        val ipv4 = addresses.filterIsInstance<Inet4Address>().filter { !it.isLoopbackAddress }
        (ipv4.firstOrNull { address ->
            val bytes = address.address.map { it.toInt() and 0xff }
            bytes[0] == 10 || (bytes[0] == 172 && bytes[1] in 16..31) ||
                (bytes[0] == 192 && bytes[1] == 168)
        } ?: ipv4.firstOrNull())?.hostAddress
    } catch (_: Exception) { null }

    companion object {
        const val PORT = 38470
        const val DISCOVERY_PORT = 38471
        const val DISCOVER_TOKEN = "FREECHAT_LAN_DISCOVER_V1"
    }
}
