package com.freechat.lan

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity(), LanNetwork.Listener {
    private lateinit var network: LanNetwork
    private lateinit var status: TextView
    private lateinit var peers: TextView
    private lateinit var messages: TextView
    private lateinit var nameInput: EditText
    private lateinit var ipInput: EditText
    private lateinit var messageInput: EditText
    private val history = StringBuilder()
    private var dark = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        network = LanNetwork(this, this)
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16, 12, 16, 12); setBackgroundColor(if (dark) Color.rgb(18, 25, 35) else Color.rgb(244, 247, 251)) }
        val title = TextView(this).apply { text = "FreeChat LAN"; textSize = 25f; typeface = Typeface.DEFAULT_BOLD; setTextColor(if (dark) Color.WHITE else Color.rgb(16, 59, 102)); gravity = Gravity.CENTER; setPadding(4, 8, 4, 12) }
        root.addView(title, matchWrap())
        status = TextView(this).apply { text = "آفلاین • برای شروع میزبان شوید یا متصل شوید"; textSize = 14f; setTextColor(Color.DKGRAY); setPadding(8, 8, 8, 8) }
        root.addView(status, matchWrap())
        nameInput = EditText(this).apply { hint = "نام نمایشی شما"; setSingleLine(true); setText("کاربر") }
        root.addView(nameInput, matchWrap())
        val hostRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val hostBtn = Button(this).apply { text = "راه‌اندازی سرور میزبان"; setOnClickListener { startHost() } }
        val scanBtn = Button(this).apply { text = "پیدا کردن میزبان"; setOnClickListener { scanHosts() } }
        hostRow.addView(hostBtn, LinearLayout.LayoutParams(0, dp(52), 1f)); hostRow.addView(scanBtn, LinearLayout.LayoutParams(0, dp(52), 1f)); root.addView(hostRow, matchWrap())
        ipInput = EditText(this).apply { hint = "IP میزبان، مثلاً 192.168.43.1"; setSingleLine(true); inputType =  android.text.InputType.TYPE_CLASS_TEXT }
        root.addView(ipInput, matchWrap())
        val joinRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val joinBtn = Button(this).apply { text = "اتصال به IP"; setOnClickListener { val ip = ipInput.text.toString().trim(); if (ip.isNotEmpty()) network.connect(ip, displayName()) else toast("IP میزبان را وارد کن") } }
        val leaveBtn = Button(this).apply { text = "قطع اتصال"; setOnClickListener { network.stop(); status.text = "ارتباط قطع شد" } }
        joinRow.addView(joinBtn, LinearLayout.LayoutParams(0, dp(48), 1f)); joinRow.addView(leaveBtn, LinearLayout.LayoutParams(0, dp(48), 1f)); root.addView(joinRow, matchWrap())
        peers = TextView(this).apply { text = "اعضای متصل: 0"; textSize = 13f; setTextColor(Color.GRAY); setPadding(8, 8, 8, 4) }
        root.addView(peers, matchWrap())
        val chatTitle = TextView(this).apply { text = "گفت‌وگوی گروهی"; textSize = 17f; typeface = Typeface.DEFAULT_BOLD; setTextColor(if (dark) Color.WHITE else Color.rgb(16, 59, 102)); setPadding(8, 8, 8, 8) }
        root.addView(chatTitle, matchWrap())
        val scroll = ScrollView(this).apply { isFillViewport = true; setBackgroundColor(if (dark) Color.rgb(29, 39, 52) else Color.WHITE) }
        messages = TextView(this).apply { text = "پیام‌ها پس از بستن برنامه نگهداری نمی‌شوند.\n"; textSize = 15f; setTextColor(if (dark) Color.WHITE else Color.DKGRAY); setPadding(12, 12, 12, 12) }
        scroll.addView(messages, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        val sendRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        messageInput = EditText(this).apply { hint = "پیام بنویس..."; maxLines = 3 }
        val sendBtn = Button(this).apply { text = "ارسال"; setOnClickListener { val text = messageInput.text.toString().trim(); if (text.isNotEmpty()) { network.sendText(text); messageInput.setText("") } } }
        sendRow.addView(messageInput, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)); sendRow.addView(sendBtn, LinearLayout.LayoutParams(dp(84), dp(52))); root.addView(sendRow, matchWrap())
        val bottom = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val clearBtn = Button(this).apply { text = "پاک‌کردن گفتگو"; setOnClickListener { history.setLength(0); messages.text = "گفتگو پاک شد.\n" } }
        val themeBtn = Button(this).apply { text = "حالت شب/روز"; setOnClickListener { dark = !dark; buildUi() } }
        bottom.addView(clearBtn, LinearLayout.LayoutParams(0, dp(46), 1f)); bottom.addView(themeBtn, LinearLayout.LayoutParams(0, dp(46), 1f)); root.addView(bottom, matchWrap())
        setContentView(root)
    }

    private fun startHost() {
        network.startHost(displayName())
        toast("سرور خودکار اجرا شد. هات‌اسپات گوشی باید از تنظیمات روشن باشد.")
    }

    private fun scanHosts() {
        status.text = "در حال جست‌وجوی میزبان‌ها..."
        network.discoverHost { ip, hostName -> runOnUiThread {
            AlertDialog.Builder(this).setTitle("میزبان پیدا شد")
                .setMessage("$hostName\n$ip")
                .setPositiveButton("اتصال") { _, _ -> ipInput.setText(ip); network.connect(ip, displayName()) }
                .setNegativeButton("بستن", null).show()
        } }
    }

    private fun displayName(): String = nameInput.text.toString().trim().ifEmpty { "کاربر" }
    override fun onStatus(message: String) { runOnUiThread { status.text = message } }
    override fun onPeerCount(count: Int) { runOnUiThread { peers.text = "اعضای متصل: $count" } }
    override fun onError(message: String) { runOnUiThread { status.text = message; toast(message) } }
    override fun onMessage(message: ChatMessage) {
        runOnUiThread {
            val line = "[${message.displayTime()}] ${message.senderName}: ${message.text}\n"
            history.append(line); messages.text = history.toString()
        }
    }

    private fun matchWrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density + 0.5f).toInt()
    private fun toast(value: String) = Toast.makeText(this, value, Toast.LENGTH_LONG).show()
    override fun onDestroy() { network.stop(); super.onDestroy() }
}
