package com.freechat.lan

import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

 data class ChatMessage(
    val id: String,
    val senderId: String,
    val senderName: String,
    val text: String,
    val time: Long,
    val targetId: String = "*"
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("type", "MESSAGE"); put("id", id); put("senderId", senderId)
        put("senderName", senderName); put("text", text); put("time", time); put("targetId", targetId)
    }
    fun displayTime(): String = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(time))
    companion object {
        fun fromJson(o: JSONObject) = ChatMessage(
            o.optString("id"), o.optString("senderId"), o.optString("senderName"),
            o.optString("text"), o.optLong("time"), o.optString("targetId", "*")
        )
    }
}
