package org.coolercontrol.app

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager as AndroidBluetoothManager
import android.bluetooth.BluetoothSocket
import android.content.Context
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.util.UUID
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Thread-safe Bluetooth Classic SPP manager for Android HC-05.
 * Direct Kotlin translation of bluetooth_manager.py
 */
class BluetoothManager(
    context: Context,
    private val onLine: ((String) -> Unit)? = null,
    private val onState: ((Boolean, String) -> Unit)? = null
) {
    companion object {
        const val SPP_UUID_STRING = "00001101-0000-1000-8000-00805F9B34FB"
        val SPP_UUID: UUID = UUID.fromString(SPP_UUID_STRING)
    }

    @Suppress("DEPRECATION")
    private val adapter: BluetoothAdapter? =
        if (android.os.Build.VERSION.SDK_INT >= 18) {
            (context.getSystemService(Context.BLUETOOTH_SERVICE) as? AndroidBluetoothManager)?.adapter
        } else {
            BluetoothAdapter.getDefaultAdapter()
        }

    private var socket: BluetoothSocket? = null
    private var readerThread: Thread? = null
    private val stopEvent = AtomicBoolean(false)
    private val writeLock = Any()
    private val stateLock = Any()

    @Volatile
    private var connected = false

    private fun notifyState(isConnected: Boolean, message: String) {
        try {
            onState?.invoke(isConnected, message)
        } catch (_: Exception) {
        }
    }

    @SuppressLint("MissingPermission")
    fun getPairedDevices(): List<Pair<String, String>> {
        val btAdapter = adapter ?: throw RuntimeException("Bluetooth فقط در محیط اندروید در دسترس است")
        if (!btAdapter.isEnabled) {
            throw RuntimeException("بلوتوث گوشی خاموش است")
        }
        val bonded = btAdapter.bondedDevices ?: return emptyList()
        return bonded
            .map { device ->
                val name = device.name ?: "بدون نام"
                val address = device.address ?: ""
                name to address
            }
            .sortedBy { it.first.lowercase() }
    }

    @SuppressLint("MissingPermission")
    fun connect(address: String) {
        disconnect(notify = false)
        val btAdapter = adapter ?: throw RuntimeException("Android Bluetooth API در دسترس نیست")
        if (!btAdapter.isEnabled) {
            throw RuntimeException("ابتدا بلوتوث گوشی را روشن کنید")
        }

        try {
            val device: BluetoothDevice = btAdapter.getRemoteDevice(address)
            try {
                btAdapter.cancelDiscovery()
            } catch (_: Exception) {
            }

            var btSocket: BluetoothSocket? = null
            try {
                btSocket = device.createRfcommSocketToServiceRecord(SPP_UUID)
                btSocket.connect()
            } catch (_: Exception) {
                try {
                    btSocket?.close()
                } catch (_: Exception) {
                }
                // HC-05 modules sometimes need the insecure SPP socket.
                btSocket = device.createInsecureRfcommSocketToServiceRecord(SPP_UUID)
                btSocket.connect()
            }

            synchronized(stateLock) {
                socket = btSocket
                connected = true
                stopEvent.set(false)
            }

            readerThread = Thread({ readLoop() }, "BluetoothReader").apply {
                isDaemon = true
                start()
            }

            notifyState(true, "اتصال برقرار شد: ${device.name ?: address}")
        } catch (exc: Exception) {
            disconnect(notify = false)
            notifyState(false, "اتصال ناموفق: ${exc.message}")
            throw exc
        }
    }

    fun disconnect(notify: Boolean = true) {
        stopEvent.set(true)
        val sock: BluetoothSocket?
        synchronized(stateLock) {
            sock = socket
            socket = null
            connected = false
        }
        if (sock != null) {
            try {
                sock.close()
            } catch (_: Exception) {
            }
        }
        if (notify) {
            notifyState(false, "اتصال قطع شد")
        }
    }

    fun isConnected(): Boolean {
        synchronized(stateLock) {
            val s = socket
            if (!connected || s == null) return false
            return try {
                s.isConnected
            } catch (_: Exception) {
                connected
            }
        }
    }

    /**
     * Send command followed by one LF; strip accidental line endings first.
     */
    fun send(rawCommand: String) {
        // ✅ اصلاح شد: استفاده از \n و \r به جای خط جدید واقعی
        val command = rawCommand.trimEnd('\n', '\r')
        if (command.isEmpty()) {
            throw IllegalArgumentException("دستور خالی قابل ارسال نیست")
        }

        val sock: BluetoothSocket?
        val isConn: Boolean
        synchronized(stateLock) {
            sock = socket
            isConn = connected
        }

        if (!isConn || sock == null) {
            throw IOException("بلوتوث متصل نیست")
        }

        // ✅ اصلاح شد: استفاده از \n به جای خط جدید واقعی
        val payload = (command + "\n").toByteArray(Charsets.UTF_8)
        synchronized(writeLock) {
            val outputStream = sock.outputStream
            outputStream.write(payload)
            outputStream.flush()
        }
    }

    private fun readLoop() {
        val buffer = ByteArrayOutputStream()
        try {
            while (!stopEvent.get()) {
                val sock = synchronized(stateLock) { socket } ?: break
                val stream = sock.inputStream
                val available = stream.available()
                if (available <= 0) {
                    Thread.sleep(30)
                    continue
                }

                val limit = minOf(available, 512)
                for (i in 0 until limit) {
                    val value = stream.read()
                    if (value < 0) {
                        throw IOException("ارتباط بلوتوث بسته شد")
                    }
                    if (value == 10) { // LF
                        // ✅ اصلاح شد: استفاده از \r و \n به جای خط جدید واقعی
                        val line = buffer.toString("UTF-8").trimEnd('\r', '\n')
                        buffer.reset()
                        if (line.isNotEmpty()) {
                            try {
                                onLine?.invoke(line)
                            } catch (_: Exception) {
                            }
                        }
                    } else {
                        if (buffer.size() < 4096) {
                            buffer.write(value)
                        } else {
                            buffer.reset()
                        }
                    }
                }
            }
        } catch (exc: Exception) {
            if (!stopEvent.get()) {
                notifyState(false, "خطای دریافت: ${exc.message}")
            }
        } finally {
            if (!stopEvent.get()) {
                disconnect(notify = true)
            }
        }
    }
}