package org.coolercontrol.app

import android.widget.Button
import android.widget.TextView

/**
 * Four-digit numeric keypad controller for RTC time entry.
 * Direct Kotlin translation of numeric_keypad.py
 */
class NumericKeypadController(
    private val display: TextView,
    digitButtons: Map<String, Button>,
    delButton: Button,
    clrButton: Button,
    confirmButton: Button,
    private val onChange: ((String) -> Unit)? = null,
    private val onConfirm: ((String) -> Unit)? = null
) {
    var value: String = ""
        private set

    init {
        for ((digit, button) in digitButtons) {
            button.setOnClickListener { press(digit) }
        }
        delButton.setOnClickListener { press("DEL") }
        clrButton.setOnClickListener { press("CLR") }
        confirmButton.setOnClickListener { press("OK") }
        updateDisplay()
    }

    fun press(key: String) {
        when (key) {
            "⌫", "DEL" -> {
                if (value.isNotEmpty()) {
                    value = value.dropLast(1)
                }
            }
            "CLR", "Clear" -> {
                value = ""
            }
            "OK", "✓", "Enter", "تأیید" -> {
                onConfirm?.invoke(value)
                updateDisplay()
                return
            }
            else -> {
                if (key.length == 1 && key[0].isDigit() && value.length < 4) {
                    value += key
                }
            }
        }
        updateDisplay()
        onChange?.invoke(value)
    }

    private fun updateDisplay() {
        val digits = value.padEnd(4, '-')
        display.text = "${digits.substring(0, 2)}:${digits.substring(2)}"
    }

    fun clear() {
        value = ""
        updateDisplay()
        onChange?.invoke(value)
    }
}
