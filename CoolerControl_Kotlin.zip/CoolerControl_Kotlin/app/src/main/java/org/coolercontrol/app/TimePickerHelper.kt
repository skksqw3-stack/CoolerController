package org.coolercontrol.app

import android.content.Context
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Spinner

/**
 * Reusable 24-hour time picker controller with hour and minute spinners.
 * Direct Kotlin translation of time_picker.py
 */
class TimePickerHelper(
    context: Context,
    private val hourSpinner: Spinner,
    private val minuteSpinner: Spinner,
    initialHour: Int = 7,
    initialMinute: Int = 30,
    private val onTimeChange: (() -> Unit)? = null
) {
    var hour: Int = initialHour
        private set
    var minute: Int = initialMinute
        private set

    init {
        val hours = (0..23).map { String.format("%02d", it) }
        val minutes = (0..59).map { String.format("%02d", it) }

        val hourAdapter = ArrayAdapter(context, android.R.layout.simple_spinner_item, hours).apply {
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }
        val minuteAdapter = ArrayAdapter(context, android.R.layout.simple_spinner_item, minutes).apply {
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }

        hourSpinner.adapter = hourAdapter
        minuteSpinner.adapter = minuteAdapter

        setTime(initialHour, initialMinute)

        hourSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, pos: Int, id: Long) {
                hour = pos
                onTimeChange?.invoke()
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        minuteSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, pos: Int, id: Long) {
                minute = pos
                onTimeChange?.invoke()
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
    }

    fun getTimeString(): String = String.format("%02d%02d", hour, minute)

    fun setTime(h: Int, m: Int) {
        if (h !in 0..23 || m !in 0..59) {
            throw IllegalArgumentException("زمان باید بین 00:00 و 23:59 باشد")
        }
        hour = h
        minute = m
        hourSpinner.setSelection(h)
        minuteSpinner.setSelection(m)
        onTimeChange?.invoke()
    }
}
