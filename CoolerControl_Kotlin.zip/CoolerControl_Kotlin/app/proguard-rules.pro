# Keep Bluetooth & ViewBinding classes
-keep class org.coolercontrol.app.** { *; }
