CoolerController - Android 4.4.4 compatibility build

Minimum Android version: Android 4.4 (API 19).
The app uses Bluetooth Classic RFCOMM/SPP for HC-05.

Compatibility changes:
- minSdk lowered to 19 (Android 4.4 / 4.4.4).
- Java/Kotlin bytecode target changed to Java 8.
- AndroidX AppCompat and Material dependencies pinned to versions compatible with API 19.
- Legacy BLUETOOTH and BLUETOOTH_ADMIN permissions remain declared for Android 4.4 through 11.
- BLUETOOTH_CONNECT remains declared for Android 12 and newer. Runtime permission handling is only needed on Android 12+.

Build environment: Android Gradle Plugin 8.5.2 requires JDK 17 to build.
This does NOT mean the app requires Android 17; JDK 17 is only the build toolchain.

Important: The source was adjusted for API 19 compatibility, but a real build and on-device test on Android 4.4.4 are still required.
